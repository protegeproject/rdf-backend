/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.storage.rdf.oil;

import java.util.*;

import org.w3c.rdf.model.*;
import org.w3c.rdf.vocabulary.rdf_schema_19990303.*;
import org.w3c.rdf.vocabulary.rdf_syntax_19990222.*;

import edu.stanford.smi.protegex.storage.rdf.*;


public class OilFrame extends RDFFrame implements OilConstants {

  public OilFrame(Resource resource, 
		  Collection classes, Collection properties) {
    super(resource, classes, properties);
  }

  public boolean isThing() {
    return isOilSystemResource("Top") ||
      _resource.equals(RDFS.Resource) || // should not be necessary, but ...
      _resource.equals(RDFS.ConstraintResource); 
  }

  public boolean isStandardClass() {
    return isOilSystemResource("Class") ||
      _resource.equals(RDFS.Class);
  }

  public boolean isStandardSlot() {
    return isOilSystemResource("Property") ||
      isOilSystemResource("TransitiveProperty") ||
      isOilSystemResource("SymmetricProperty") ||
      isOilSystemResource("FunctionalProperty") ||
      _resource.equals(RDF.Property) ||
      _resource.equals(RDFS.ConstraintProperty);
  }

  boolean isOilSystemResource(String name) {
    try {
      String namespace = _resource.getNamespace();
      String localName = _resource.getLocalName();
      return OILNAMESPACE.equals(namespace) && localName.equals(name);
    } catch (Exception e) { return false; }
  }


}


