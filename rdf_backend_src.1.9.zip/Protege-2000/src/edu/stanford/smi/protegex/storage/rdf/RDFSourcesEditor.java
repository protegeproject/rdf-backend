/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.storage.rdf;

import java.awt.*;
import java.io.*;

import javax.swing.*;
import javax.swing.event.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;


public class RDFSourcesEditor extends KnowledgeBaseSourcesEditor {

  static final String PROTEGEURI = "http://protege.stanford.edu/";

  FileField _clsesField;
  FileField _instancesField;
  JTextField _namespaceField;

  String _setNamespace;
  boolean _updateNamespaceField;

  public RDFSourcesEditor(String projectPath, PropertyList sources) {
    super(projectPath, sources);
    JPanel panel = new JPanel();
    panel.setLayout(new GridLayout(0, 1, 10, 10));
    panel.add(createClsesField());
    panel.add(createInstancesField());
    panel.add(createNamespaceField());
    add(panel);
  }

  // overwritten methods from the KnowledgeBaseSourcesEditor class ----------

  public void onProjectPathChange(String oldPath, String newPath) {
    if (newPath != null) {
      updatePath(_clsesField, ".rdfs");
      updatePath(_instancesField, ".rdf");
      if (_updateNamespaceField)
	updateNamespace(_namespaceField);
    }
  }

  public String getProjectPath() { // from Ray
    String path = super.getProjectPath();
    if (path == null && _clsesField != null) {
      String text = _clsesField.getPath();
      if (text != null) {
	text = text.substring(0, text.length() - 4);
	text += "pprj";
	path = text;
      }
    }
    return path;
  }


  // methods implementing the Validatable interface ------------------------

  public void saveContents() {
    String clsesFileName = _clsesField.getPath();
    String instancesFileName = _instancesField.getPath();
    String namespace = _namespaceField.getText();
    RDFBackend.setSourceFiles(getSources(), clsesFileName,
      instancesFileName, namespace);
  }

  public boolean validateContents() {
    boolean isComplete =
      hasValidValue(_clsesField) && hasValidValue(_instancesField);
    if (!isComplete) {
        // TODO ... !!!
        isComplete = true;
    }
    return isComplete;
  }


  // GUI stuff ------------------------------------------------------------

  public JComponent createClsesField() {
    String name = RDFBackend.getClsesFileName(getSources());
    name = constructName(name, getProjectPath(), ".rdfs");
    _clsesField =
      new FileField("Classes file name", name, ".rdfs", "Ontology");
    return _clsesField;
  }

  public JComponent createInstancesField() {
    String name = RDFBackend.getInstancesFileName(getSources());
    name = constructName(name, getProjectPath(), ".rdf");
    _instancesField =
      new FileField("Instances file name", name, ".rdf", "Instances");
    return _instancesField;
  }

  public JComponent createNamespaceField() {
    String namespace = RDFBackend.getNamespace(getSources());
    if (namespace == null || namespace.trim().length() == 0) {
      String projectName = getProjectName();
      if (projectName == null) projectName = "kb";
      namespace = getNamespace(projectName);
      _updateNamespaceField = true;
    } else { // namespace already existed, so don't change it automatically
      _updateNamespaceField = false;
    }
    _namespaceField = ComponentFactory.createTextField();
    setNamespaceField(namespace);
    _namespaceField.getDocument().addDocumentListener(new DocumentListener() {
      public void changedUpdate(DocumentEvent de) { check(); }
      public void insertUpdate(DocumentEvent de) { check(); }
      public void removeUpdate(DocumentEvent de) { check(); }
      void check() {
	String namespaceTF = _namespaceField.getText();
	if (_updateNamespaceField &&
	    !namespaceTF.equals("") &&
	    !namespaceTF.equals(_setNamespace))
	  // user has changed the field, so never automatically change it:
	  _updateNamespaceField = false;
      }
    });
    return new LabeledComponent("Namespace", _namespaceField);
  }

  void setNamespaceField(String namespace) {
    _setNamespace = namespace; // remember namespace set automatically
    _namespaceField.setText(namespace);
  }


  // auxiliaries -------------------------------------------------------

  String constructName(String name, String projectPath, String extension) {
    if (name == null) {
      if (projectPath != null) {
	File projectFile = new File(getProjectPath());
        name = projectFile.getName();
      }
    }
    if (name != null) {
      int index = name.indexOf(".");
      if (index != -1)
        name = name.substring(0, index) + extension;
      else
        name = name + extension;
    }
    return name;
  }

  boolean hasValidValue(FileField field) {
    boolean hasValidValue;
    String value = field.getPath();
    if (value == null || value.length() == 0) {
      hasValidValue = false;
    } else {
      // other tests???
      hasValidValue = true;
    }
    return hasValidValue;
  }

  void updatePath(FileField field, String ext) {
    String projectName = getProjectName();
    if (projectName != null) {
      String newPath = projectName + ext;
      field.setPath(newPath);
    }
  }

  void updateNamespace(JTextField field) {
    String projectName = getProjectName();
    if (projectName != null) {
      String newNamespace = getNamespace(projectName);
      setNamespaceField(newNamespace);
    }
  }

  String getNamespace(String projectName) {
    String namespace = PROTEGEURI + projectName + "#";
    // remove spaces, ' and "
    if (namespace.indexOf(' ') != -1)
      namespace = namespace.replace(' ', '_');
    if (namespace.indexOf('\'') != -1)
      namespace = namespace.replace('\'', '_');
    if (namespace.indexOf('\"') != -1)
      namespace = namespace.replace('\"', '_');
    // shorten if too long ... !!!
    return namespace;
  }

  String getProjectName() {
    String projectPath = getProjectPath();
    if (projectPath != null && !projectPath.equals("")) {
      File projectFile = new File(getProjectPath());
      String projectName = projectFile.getName();
      int index = projectName.indexOf(".");
      if (index != -1) {
	projectName = projectName.substring(0, index);
      }
      return projectName;
    } else {
      return null;
    }
  }


}


